package com.motophone.ui

import android.Manifest
import android.provider.CallLog
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.motophone.data.CallLogEntry
import com.motophone.data.CallLogRepo
import com.motophone.data.ContactItem
import com.motophone.data.ContactsRepo
import com.motophone.data.DefaultDialer
import com.motophone.data.Perms
import com.motophone.data.Prefs
import com.motophone.telecom.CallPlacer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun MotoApp(prefill: String?, onPrefillConsumed: () -> Unit) {
    val ctx = LocalContext.current

    // Refresh data whenever we come back to the foreground
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    var granted by remember { mutableStateOf(Perms.hasCore(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = Perms.hasCore(ctx)
        tick++
    }
    LaunchedEffect(Unit) { if (!Perms.hasAll(ctx)) permLauncher.launch(Perms.all) }

    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { tick++ }
    val isDefault = remember(tick) { DefaultDialer.isHeld(ctx) }
    val makeDefault = { roleLauncher.launch(DefaultDialer.requestIntent(ctx)); Unit }

    val contacts by produceState(emptyList<ContactItem>(), tick, granted) {
        value = withContext(Dispatchers.IO) { ContactsRepo.load(ctx) }
    }
    val callLog by produceState(emptyList<CallLogEntry>(), tick, granted) {
        value = withContext(Dispatchers.IO) { CallLogRepo.load(ctx) }
    }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var number by rememberSaveable { mutableStateOf("") }
    var showSettings by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(prefill) {
        if (prefill != null) {
            number = prefill
            tab = 0
            showSettings = false
            onPrefillConsumed()
        }
    }

    // ---- Calling (with dual-SIM chooser) ----
    var pendingCall by remember { mutableStateOf<String?>(null) }
    fun startCall(n: String) {
        if (n.isBlank()) return
        if (!Perms.has(ctx, Manifest.permission.CALL_PHONE)) {
            permLauncher.launch(Perms.all)
            return
        }
        val accounts = CallPlacer.accounts(ctx)
        if (accounts.size > 1 && Prefs.bool(ctx, Prefs.ASK_SIM)) pendingCall = n
        else runCatching { CallPlacer.call(ctx, n) }
    }

    pendingCall?.let { num ->
        val accounts = remember(num) { CallPlacer.accounts(ctx) }
        AlertDialog(
            onDismissRequest = { pendingCall = null },
            title = { Text("Call with") },
            text = {
                Column {
                    accounts.forEachIndexed { i, h ->
                        TextButton(
                            onClick = { runCatching { CallPlacer.call(ctx, num, h) }; pendingCall = null },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("SIM ${i + 1} · ${CallPlacer.label(ctx, h)}") }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pendingCall = null }) { Text("Cancel") } }
        )
    }

    val requestPerms = { permLauncher.launch(Perms.all); Unit }
    val lastDialed = callLog.firstOrNull { it.type == CallLog.Calls.OUTGOING_TYPE }?.number

    if (showSettings) {
        BackHandler { showSettings = false }
        Box(Modifier.fillMaxSize()) {
            SettingsScreen(isDefault, makeDefault) { showSettings = false }
        }
        return
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.background) {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.Dialpad, null) }, label = { Text("Keypad") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Filled.History, null) }, label = { Text("Recents") }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Filled.Person, null) }, label = { Text("Contacts") }
                )
            }
        }
    ) { inner ->
        Box(Modifier.padding(inner).fillMaxSize()) {
            when (tab) {
                0 -> KeypadScreen(
                    number = number, onNumber = { number = it }, contacts = contacts,
                    lastDialed = lastDialed, isDefault = isDefault, onMakeDefault = makeDefault,
                    onCall = { startCall(it) }, onOpenSettings = { showSettings = true }
                )
                1 -> RecentsScreen(
                    entries = callLog,
                    hasPermission = Perms.has(ctx, Manifest.permission.READ_CALL_LOG),
                    onRequestPermission = requestPerms,
                    onCall = { startCall(it) },
                    onChanged = { tick++ },
                    onOpenSettings = { showSettings = true }
                )
                else -> ContactsScreen(
                    contacts = contacts,
                    hasPermission = Perms.has(ctx, Manifest.permission.READ_CONTACTS),
                    onRequestPermission = requestPerms,
                    onCall = { startCall(it) },
                    onChanged = { tick++ },
                    onOpenSettings = { showSettings = true }
                )
            }
        }
    }
}
