package com.motophone.data

import android.content.Context

object Prefs {
    const val KEYPAD_TONES = "keypad_tones"
    const val KEYPAD_HAPTIC = "keypad_haptic"
    const val PROXIMITY = "proximity"
    const val ASK_SIM = "ask_sim"

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("moto_phone", Context.MODE_PRIVATE)

    fun bool(c: Context, key: String, def: Boolean = true): Boolean = sp(c).getBoolean(key, def)

    fun setBool(c: Context, key: String, v: Boolean) {
        sp(c).edit().putBoolean(key, v).apply()
    }

    fun speedDial(c: Context, digit: Int): String? = sp(c).getString("sd_$digit", null)

    fun setSpeedDial(c: Context, digit: Int, number: String?) {
        val e = sp(c).edit()
        if (number.isNullOrBlank()) e.remove("sd_$digit") else e.putString("sd_$digit", number.trim())
        e.apply()
    }

    val defaultDeclineMessages = listOf(
        "Can't talk now. What's up?",
        "I'll call you right back.",
        "I'll call you later.",
        "Can't talk now. Call me later?"
    )

    fun declineMessages(c: Context): List<String> =
        sp(c).getString("decline_msgs", null)
            ?.split('\u0001')
            ?.filter { it.isNotBlank() }
            ?: defaultDeclineMessages

    fun setDeclineMessages(c: Context, list: List<String>) {
        sp(c).edit()
            .putString("decline_msgs", list.filter { it.isNotBlank() }.joinToString("\u0001"))
            .apply()
    }
}
