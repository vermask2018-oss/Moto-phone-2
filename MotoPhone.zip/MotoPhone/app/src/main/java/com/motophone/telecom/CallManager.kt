@file:Suppress("DEPRECATION")

package com.motophone.telecom

import android.content.Context
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import com.motophone.data.ContactsRepo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CallInfo(
    val call: Call,
    val state: Int,
    val number: String,
    val name: String?,
    val connectTime: Long,
    val canHold: Boolean,
    val canMerge: Boolean,
    val isConference: Boolean,
)

/** Holds every live call handed to us by the system (main thread only). */
object CallManager {
    private val tracked = LinkedHashMap<Call, Call.Callback>()
    private val _state = MutableStateFlow<List<CallInfo>>(emptyList())
    val state: StateFlow<List<CallInfo>> = _state.asStateFlow()

    private val _audio = MutableStateFlow<CallAudioState?>(null)
    val audio: StateFlow<CallAudioState?> = _audio.asStateFlow()

    var service: InCallService? = null
    var onChanged: ((List<CallInfo>) -> Unit)? = null

    private var appCtx: Context? = null
    private val nameCache = HashMap<String, String?>()

    fun add(ctx: Context, call: Call) {
        appCtx = ctx.applicationContext
        if (tracked.containsKey(call)) return
        val cb = object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) = refresh()
            override fun onDetailsChanged(call: Call, details: Call.Details) = refresh()
            override fun onCallDestroyed(call: Call) = remove(call)
        }
        call.registerCallback(cb)
        tracked[call] = cb
        _audio.value = service?.callAudioState
        refresh()
    }

    fun remove(call: Call) {
        tracked.remove(call)?.let { call.unregisterCallback(it) }
        refresh()
    }

    fun setAudio(s: CallAudioState?) {
        _audio.value = s
    }

    private fun refresh() {
        val list = tracked.keys.map { buildInfo(it) }
        _state.value = list
        onChanged?.invoke(list)
    }

    private fun buildInfo(call: Call): CallInfo {
        val d = call.details
        val number = d.handle?.schemeSpecificPart ?: ""
        val ctx = appCtx
        val name = when {
            number.isBlank() || ctx == null -> null
            nameCache.containsKey(number) && nameCache[number] != null -> nameCache[number]
            else -> ContactsRepo.lookupName(ctx, number).also { nameCache[number] = it }
        } ?: d.callerDisplayName?.takeIf { it.isNotBlank() }
        return CallInfo(
            call = call,
            state = call.state,
            number = number,
            name = name,
            connectTime = d.connectTimeMillis,
            canHold = d.can(Call.Details.CAPABILITY_HOLD),
            canMerge = d.can(Call.Details.CAPABILITY_MERGE_CONFERENCE),
            isConference = d.hasProperty(Call.Details.PROPERTY_CONFERENCE),
        )
    }

    /** The call the UI should focus on. */
    fun primary(list: List<CallInfo>): CallInfo? =
        list.firstOrNull { it.state == Call.STATE_RINGING }
            ?: list.firstOrNull {
                it.state == Call.STATE_ACTIVE || it.state == Call.STATE_DIALING ||
                    it.state == Call.STATE_CONNECTING || it.state == Call.STATE_PULLING_CALL ||
                    it.state == Call.STATE_SELECT_PHONE_ACCOUNT
            }
            ?: list.firstOrNull { it.state != Call.STATE_DISCONNECTED }
            ?: list.firstOrNull()

    // ---- Actions -------------------------------------------------------------

    fun answerRinging() {
        _state.value.firstOrNull { it.state == Call.STATE_RINGING }
            ?.call?.answer(VideoProfile.STATE_AUDIO_ONLY)
    }

    fun rejectRinging() {
        _state.value.firstOrNull { it.state == Call.STATE_RINGING }?.call?.reject(false, null)
    }

    fun rejectWithMessage(call: Call, message: String) {
        call.reject(true, message)
    }

    fun disconnect(call: Call) {
        call.disconnect()
    }

    fun hangupAll() {
        tracked.keys.toList().forEach { it.disconnect() }
    }

    fun toggleHold(info: CallInfo) {
        if (info.state == Call.STATE_HOLDING) info.call.unhold() else info.call.hold()
    }

    /** Make the other (held) call the active one. */
    fun swapTo(other: CallInfo) {
        other.call.unhold()
    }

    fun merge(a: CallInfo, b: CallInfo) {
        a.call.conference(b.call)
    }

    fun setMuted(muted: Boolean) {
        service?.setMuted(muted)
    }

    fun setSpeaker(on: Boolean) {
        service?.setAudioRoute(
            if (on) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_WIRED_OR_EARPIECE
        )
    }

    fun setBluetooth(on: Boolean) {
        service?.setAudioRoute(
            if (on) CallAudioState.ROUTE_BLUETOOTH else CallAudioState.ROUTE_WIRED_OR_EARPIECE
        )
    }
}
