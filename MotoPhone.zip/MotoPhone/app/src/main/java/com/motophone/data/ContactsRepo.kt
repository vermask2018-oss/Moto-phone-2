package com.motophone.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.PhoneLookup

object ContactsRepo {

    fun load(ctx: Context): List<ContactItem> {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return emptyList()
        }
        class Builder(
            val id: Long,
            val name: String,
            val lookup: String?,
            val photo: String?,
            val starred: Boolean,
        ) {
            val numbers = LinkedHashMap<String, String>()
        }

        val map = LinkedHashMap<Long, Builder>()
        val projection = arrayOf(
            Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER,
            Phone.PHOTO_THUMBNAIL_URI, Phone.STARRED, Phone.LOOKUP_KEY
        )
        runCatching {
            ctx.contentResolver.query(
                Phone.CONTENT_URI, projection, null, null, "${Phone.SORT_KEY_PRIMARY} ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val b = map.getOrPut(id) {
                        Builder(id, c.getString(1) ?: "", c.getString(5), c.getString(3), c.getInt(4) == 1)
                    }
                    val num = c.getString(2) ?: continue
                    b.numbers.putIfAbsent(num.filter { it.isDigit() || it == '+' }, num)
                }
            }
        }
        return map.values.map {
            ContactItem(
                id = it.id,
                name = it.name.ifBlank { it.numbers.values.firstOrNull() ?: "" },
                numbers = it.numbers.values.toList(),
                photoUri = it.photo,
                starred = it.starred,
                lookupKey = it.lookup,
            )
        }
    }

    fun lookupName(ctx: Context, number: String): String? {
        if (number.isBlank()) return null
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        return runCatching {
            val uri = Uri.withAppendedPath(PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            ctx.contentResolver.query(uri, arrayOf(PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        }.getOrNull()
    }

    // ---- Smart dial (T9) search ------------------------------------------------

    private fun t9Char(ch: Char): Char? = when (ch) {
        in 'a'..'c' -> '2'
        in 'd'..'f' -> '3'
        in 'g'..'i' -> '4'
        in 'j'..'l' -> '5'
        in 'm'..'o' -> '6'
        in 'p'..'s' -> '7'
        in 't'..'v' -> '8'
        in 'w'..'z' -> '9'
        in '0'..'9' -> ch
        ' ' -> ' '
        else -> null
    }

    private fun t9(s: String): String = s.lowercase().mapNotNull { t9Char(it) }.joinToString("")

    /** Matches contacts whose number contains the digits, or whose name (any word) T9-starts with them. */
    fun search(contacts: List<ContactItem>, typed: String): List<ContactItem> {
        val q = typed.filter { it.isDigit() }
        if (q.isEmpty()) return emptyList()
        return contacts.filter { c ->
            t9(c.name).split(' ').any { it.startsWith(q) } ||
                c.numbers.any { n -> n.filter { it.isDigit() }.contains(q) }
        }
    }
}
