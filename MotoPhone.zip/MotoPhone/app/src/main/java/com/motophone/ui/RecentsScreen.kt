package com.motophone.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CallLog.Calls
import android.provider.ContactsContract
import android.text.format.DateUtils
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.motophone.data.BlockedRepo
import com.motophone.data.CallLogEntry
import com.motophone.data.CallLogRepo
import java.text.DateFormat
import java.util.Date

private fun typeLabel(t: Int) = when (t) {
    Calls.INCOMING_TYPE -> "Incoming call"
    Calls.OUTGOING_TYPE -> "Outgoing call"
    Calls.MISSED_TYPE -> "Missed call"
    Calls.VOICEMAIL_TYPE -> "Voicemail"
    Calls.REJECTED_TYPE -> "Rejected call"
    Calls.BLOCKED_TYPE -> "Blocked call"
    else -> "Call"
}

private fun isMissedLike(t: Int) = t == Calls.MISSED_TYPE || t == Calls.REJECTED_TYPE || t == Calls.BLOCKED_TYPE

private fun typeIcon(t: Int): ImageVector = when (t) {
    Calls.INCOMING_TYPE -> Icons.AutoMirrored.Filled.CallReceived
    Calls.OUTGOING_TYPE -> Icons.AutoMirrored.Filled.CallMade
    Calls.VOICEMAIL_TYPE -> Icons.Filled.Voicemail
    Calls.BLOCKED_TYPE -> Icons.Filled.Block
    else -> Icons.AutoMirrored.Filled.CallMissed
}

private fun timeLabel(ctx: Context, millis: Long): String =
    if (DateUtils.isToday(millis)) DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(millis))
    else DateUtils.formatDateTime(ctx, millis, DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_MONTH)

private fun smsIntent(number: String) = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number"))

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RecentsScreen(
    entries: List<CallLogEntry>,
    hasPermission: Boolean,
    onRequestPermission: () -> Unit,
    onCall: (String) -> Unit,
    onChanged: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val ctx = LocalContext.current
    var filter by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var expandedId by remember { mutableStateOf<Long?>(null) }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var selecting by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf<CallLogEntry?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    val shown = remember(entries, filter, query) {
        entries.filter { e ->
            val typeOk = when (filter) {
                1 -> isMissedLike(e.type)
                2 -> e.type == Calls.INCOMING_TYPE
                3 -> e.type == Calls.OUTGOING_TYPE
                else -> true
            }
            val q = query.trim()
            typeOk && (q.isEmpty() || (e.name ?: "").contains(q, true) || e.number.contains(q))
        }
    }

    Column(Modifier.fillMaxSize()) {
        // Header
        if (selecting) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { selecting = false; selected = emptySet() }) { Icon(Icons.Filled.Close, "Cancel") }
                Text(
                    if (selected.isEmpty()) "Select items" else "${selected.size} selected",
                    fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { selected = shown.map { it.id }.toSet() }) { Text("All") }
                IconButton(onClick = { if (selected.isNotEmpty()) confirmDelete = true }) {
                    Icon(Icons.Filled.Delete, "Delete")
                }
            }
        } else {
            Row(
                Modifier.fillMaxWidth().padding(start = 24.dp, end = 8.dp, top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Recents", fontSize = 34.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                IconButton(onClick = { searching = !searching; if (!searching) query = "" }) {
                    Icon(Icons.Filled.Search, "Search")
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "More") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; selecting = true })
                        DropdownMenuItem(text = { Text("Settings") }, onClick = { menu = false; onOpenSettings() })
                    }
                }
            }
        }

        if (searching && !selecting) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("Search recents") },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }

        // Filter chips
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("All", "Missed", "Received", "Dialled").forEachIndexed { i, label ->
                FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(label) })
            }
        }

        when {
            !hasPermission -> Column(
                Modifier.fillMaxSize().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Allow call log access to see your recent calls.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onRequestPermission) { Text("Allow") }
            }
            shown.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No recent calls", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            else -> LazyColumn(Modifier.fillMaxSize()) {
                items(shown, key = { it.id }) { e ->
                    RecentRow(
                        e = e,
                        expanded = expandedId == e.id && !selecting,
                        selecting = selecting,
                        isSelected = e.id in selected,
                        onClick = {
                            if (selecting) {
                                selected = if (e.id in selected) selected - e.id else selected + e.id
                            } else {
                                expandedId = if (expandedId == e.id) null else e.id
                            }
                        },
                        onLongClick = {
                            if (!selecting) { selecting = true; selected = setOf(e.id) }
                        },
                        onCall = { if (e.number.isNotBlank()) onCall(e.number) },
                        onMessage = { runCatching { ctx.startActivity(smsIntent(e.number)) } },
                        onDetails = { detail = e },
                    )
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete call logs?") },
            text = { Text("${selected.size} item(s) will be removed from your recents.") },
            confirmButton = {
                TextButton(onClick = {
                    val ids = entries.filter { it.id in selected }.flatMap { it.ids }
                    CallLogRepo.delete(ctx, ids)
                    confirmDelete = false; selecting = false; selected = emptySet()
                    onChanged()
                }) { Text("Delete", color = EndRed) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }

    detail?.let { e ->
        val canBlock = remember { BlockedRepo.canBlock(ctx) }
        AlertDialog(
            onDismissRequest = { detail = null },
            title = { Text(e.name ?: formatNumber(e.number).ifBlank { "Private number" }) },
            text = {
                Column {
                    Text("Number: ${formatNumber(e.number).ifBlank { "Private" }}")
                    Text("Type: ${typeLabel(e.type)}")
                    Text("Time: " + DateUtils.formatDateTime(
                        ctx, e.date,
                        DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_SHOW_YEAR
                    ))
                    if (e.duration > 0) Text("Duration: ${formatDuration(e.duration)}")
                    if (e.count > 1) Text("Calls in group: ${e.count}")
                    e.geo?.let { Text("Location: $it") }
                    Spacer(Modifier.height(8.dp))
                    if (e.number.isNotBlank()) {
                        TextButton(onClick = {
                            val i = Intent(Intent.ACTION_INSERT_OR_EDIT).apply {
                                type = ContactsContract.Contacts.CONTENT_ITEM_TYPE
                                putExtra(ContactsContract.Intents.Insert.PHONE, e.number)
                            }
                            runCatching { ctx.startActivity(i) }
                            detail = null
                        }) { Text("Add to contacts") }
                        TextButton(onClick = {
                            val ok = canBlock && BlockedRepo.block(ctx, e.number)
                            Toast.makeText(
                                ctx,
                                if (ok) "Number blocked" else "Set Moto Phone as default phone app to block numbers",
                                Toast.LENGTH_SHORT
                            ).show()
                            detail = null
                        }) { Text("Block number", color = EndRed) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { detail = null }) { Text("Close") } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RecentRow(
    e: CallLogEntry,
    expanded: Boolean,
    selecting: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onCall: () -> Unit,
    onMessage: () -> Unit,
    onDetails: () -> Unit,
) {
    val ctx = LocalContext.current
    val missed = isMissedLike(e.type)
    val title = (e.name ?: formatNumber(e.number).ifBlank { "Private number" }) +
        if (e.count > 1) " (${e.count})" else ""
    val subtitle = if (e.name != null) formatNumber(e.number) else (e.geo ?: "")

    Column(
        Modifier
            .fillMaxWidth()
            .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else androidx.compose.ui.graphics.Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selecting) {
                Checkbox(checked = isSelected, onCheckedChange = null)
            } else {
                ContactAvatar(e.name, e.photoUri, 44.dp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (missed) EndRed else MaterialTheme.colorScheme.onSurface
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        typeIcon(e.type), null, Modifier.size(14.dp),
                        tint = if (missed) EndRed else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        subtitle, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Text(timeLabel(ctx, e.date), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        AnimatedVisibility(expanded) {
            Row(
                Modifier.fillMaxWidth().padding(start = 74.dp, end = 16.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ActionPill(Icons.Filled.Call, "Call", CallGreen, onCall)
                ActionPill(Icons.Filled.Sms, "Message", MaterialTheme.colorScheme.primary, onMessage)
                ActionPill(Icons.Filled.Info, "Details", MaterialTheme.colorScheme.onSurfaceVariant, onDetails)
            }
        }
    }
}

@Composable
private fun ActionPill(icon: ImageVector, label: String, tint: androidx.compose.ui.graphics.Color, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 13.sp)
    }
}
