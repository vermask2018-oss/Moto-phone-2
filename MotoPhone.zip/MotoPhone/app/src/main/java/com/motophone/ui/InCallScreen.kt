@file:Suppress("DEPRECATION")

package com.motophone.ui

import android.telecom.CallAudioState
import android.telecom.PhoneAccountHandle
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.motophone.data.Prefs
import com.motophone.telecom.CallInfo
import com.motophone.telecom.CallManager
import com.motophone.telecom.CallPlacer
import kotlinx.coroutines.delay
import android.telecom.Call as TCall

private fun availableAccounts(call: TCall): List<PhoneAccountHandle> =
    call.details.intentExtras?.getParcelableArrayList<PhoneAccountHandle>("selectPhoneAccountAccounts")
        ?: emptyList()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InCallScreen(onAddCall: () -> Unit, onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val calls by CallManager.state.collectAsState()
    val audio by CallManager.audio.collectAsState()
    val primary = CallManager.primary(calls)

    var last by remember { mutableStateOf<CallInfo?>(null) }
    SideEffect { if (primary != null) last = primary }
    val shown = primary ?: last
    val ended = calls.isEmpty()

    // Keep "Call ended" visible briefly, like One UI, then close.
    LaunchedEffect(ended) {
        if (ended) {
            delay(1200)
            onFinish()
        }
    }

    var elapsed by remember { mutableLongStateOf(0L) }
    val connect = shown?.connectTime ?: 0L
    LaunchedEffect(connect, ended) {
        while (!ended) {
            elapsed = if (connect > 0) (System.currentTimeMillis() - connect) / 1000 else 0
            delay(500)
        }
    }

    var showKeypad by remember { mutableStateOf(false) }
    var showMessages by remember { mutableStateOf(false) }
    var dtmf by remember { mutableStateOf("") }

    val other = calls.firstOrNull { it.call != primary?.call && it.state != TCall.STATE_DISCONNECTED }
    val ringing = shown?.state == TCall.STATE_RINGING && !ended
    val route = audio?.route ?: CallAudioState.ROUTE_EARPIECE
    val muted = audio?.isMuted == true
    val speakerOn = route == CallAudioState.ROUTE_SPEAKER
    val btOn = route == CallAudioState.ROUTE_BLUETOOTH
    val btAvailable = ((audio?.supportedRouteMask ?: 0) and CallAudioState.ROUTE_BLUETOOTH) != 0

    // Choose SIM when the system asks the dialer to pick an account
    if (shown != null && shown.state == TCall.STATE_SELECT_PHONE_ACCOUNT) {
        val handles = remember(shown.call) { availableAccounts(shown.call) }
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Call with") },
            text = {
                Column {
                    handles.forEachIndexed { i, h ->
                        TextButton(
                            onClick = { shown.call.phoneAccountSelected(h, false) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("SIM ${i + 1} · ${CallPlacer.label(ctx, h)}") }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { shown.call.disconnect() }) { Text("Cancel") } }
        )
    }

    val title = shown?.let { it.name ?: formatNumber(it.number).ifBlank { "Unknown" } } ?: ""
    val status = when {
        ended -> "Call ended"
        shown == null -> ""
        shown.state == TCall.STATE_RINGING -> "Incoming call"
        shown.state == TCall.STATE_DIALING || shown.state == TCall.STATE_CONNECTING ||
            shown.state == TCall.STATE_PULLING_CALL || shown.state == TCall.STATE_SELECT_PHONE_ACCOUNT -> "Calling…"
        shown.state == TCall.STATE_HOLDING -> "On hold · ${formatDuration(elapsed)}"
        shown.state == TCall.STATE_DISCONNECTING -> "Ending…"
        shown.state == TCall.STATE_ACTIVE -> formatDuration(elapsed)
        else -> ""
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                            .compositeOver(MaterialTheme.colorScheme.background),
                        MaterialTheme.colorScheme.background
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(36.dp))

            if (other != null) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0x22FFFFFF))
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            other.name ?: formatNumber(other.number).ifBlank { "Unknown" },
                            color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            if (other.state == TCall.STATE_HOLDING) "On hold" else "Waiting",
                            color = Color(0xB3FFFFFF), fontSize = 12.sp
                        )
                    }
                    if (other.state == TCall.STATE_HOLDING) {
                        TextButton(onClick = { CallManager.swapTo(other) }) { Text("Swap", color = MaterialTheme.colorScheme.primary) }
                    }
                    if (primary != null && primary.canMerge) {
                        TextButton(onClick = { CallManager.merge(primary, other) }) { Text("Merge", color = MaterialTheme.colorScheme.primary) }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            ContactAvatar(shown?.name, null, 112.dp)
            Spacer(Modifier.height(20.dp))
            Text(
                title, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Medium,
                maxLines = 2, textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis
            )
            if (shown?.name != null && shown.number.isNotBlank()) {
                Text(formatNumber(shown.number), color = Color(0xB3FFFFFF), fontSize = 16.sp)
            }
            Spacer(Modifier.height(8.dp))
            Text(status, color = Color(0xCCFFFFFF), fontSize = 18.sp)

            Spacer(Modifier.weight(1f))

            if (ringing && shown != null) {
                // Quick decline message
                Row(
                    Modifier
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0x22FFFFFF))
                        .clickable { showMessages = true }
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Sms, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Send message", color = Color.White, fontSize = 14.sp)
                }
                Spacer(Modifier.height(36.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    BigRoundButton(Icons.Filled.CallEnd, "Decline", EndRed) { CallManager.rejectRinging() }
                    BigRoundButton(Icons.Filled.Call, "Accept", CallGreen) { CallManager.answerRinging() }
                }
                Spacer(Modifier.height(40.dp))
            } else if (!ended && shown != null) {
                if (showKeypad) {
                    Text(
                        dtmf, color = Color.White, fontSize = 28.sp, maxLines = 1,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    keyRows.forEach { row ->
                        Row(Modifier.fillMaxWidth().height(64.dp)) {
                            row.forEach { (ch, sub) ->
                                PadKey(
                                    main = ch.toString(), sub = sub,
                                    modifier = Modifier.weight(1f).fillMaxHeight().padding(3.dp),
                                    onDown = { shown.call.playDtmfTone(ch); dtmf += ch },
                                    onUp = { shown.call.stopDtmfTone() },
                                )
                            }
                        }
                    }
                    TextButton(onClick = { showKeypad = false }) { Text("Hide", color = Color.White) }
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        CallControl(Icons.Filled.Add, "Add call", false, true) { onAddCall() }
                        CallControl(Icons.Filled.Pause, "Hold", shown.state == TCall.STATE_HOLDING, shown.canHold) {
                            CallManager.toggleHold(shown)
                        }
                        CallControl(Icons.Filled.Dialpad, "Keypad", false, true) { showKeypad = true }
                    }
                    Spacer(Modifier.height(20.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        CallControl(Icons.Filled.Bluetooth, "Bluetooth", btOn, btAvailable) {
                            CallManager.setBluetooth(!btOn)
                        }
                        CallControl(Icons.AutoMirrored.Filled.VolumeUp, "Speaker", speakerOn, true) {
                            CallManager.setSpeaker(!speakerOn)
                        }
                        CallControl(Icons.Filled.MicOff, "Mute", muted, true) { CallManager.setMuted(!muted) }
                    }
                }
                Spacer(Modifier.height(28.dp))
                Box(
                    Modifier.size(72.dp).clip(CircleShape).background(EndRed)
                        .clickable { CallManager.disconnect(shown.call) },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.CallEnd, "End call", tint = Color.White, modifier = Modifier.size(34.dp)) }
                Spacer(Modifier.height(36.dp))
            } else {
                Spacer(Modifier.height(120.dp))
            }
        }
    }

    if (showMessages && shown != null) {
        ModalBottomSheet(onDismissRequest = { showMessages = false }) {
            Column(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
                Text(
                    "Decline with message", fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                )
                Prefs.declineMessages(ctx).forEach { msg ->
                    Text(
                        msg, fontSize = 16.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showMessages = false
                                CallManager.rejectWithMessage(shown.call, msg)
                            }
                            .padding(horizontal = 24.dp, vertical = 14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun CallControl(icon: ImageVector, label: String, active: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.width(92.dp).alpha(if (enabled) 1f else 0.35f),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(if (active) Color.White else Color(0x26FFFFFF))
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, label, tint = if (active) Color.Black else Color.White, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color(0xCCFFFFFF), fontSize = 12.sp)
    }
}

@Composable
private fun BigRoundButton(icon: ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(76.dp).clip(CircleShape).background(color).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Icon(icon, label, tint = Color.White, modifier = Modifier.size(36.dp)) }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White, fontSize = 14.sp)
    }
}
