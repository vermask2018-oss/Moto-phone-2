package com.motophone.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

val MotoBlue = Color(0xFF3E91FF)
val CallGreen = Color(0xFF34C759)
val EndRed = Color(0xFFFF3B30)

private fun fallbackDark(): ColorScheme = darkColorScheme(
    primary = MotoBlue,
    onPrimary = Color.White,
    background = Color.Black,
    onBackground = Color.White,
    surface = Color.Black,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF252525),
    onSurfaceVariant = Color(0xFFB5B5B5),
    secondaryContainer = Color(0xFF1F3556),
    onSecondaryContainer = MotoBlue,
    outlineVariant = Color(0xFF333333),
)

private fun fallbackLight(): ColorScheme = lightColorScheme(
    primary = MotoBlue,
    onPrimary = Color.White,
    background = Color(0xFFF6F6F6),
    onBackground = Color(0xFF111111),
    surface = Color(0xFFF6F6F6),
    onSurface = Color(0xFF111111),
    surfaceVariant = Color.White,
    onSurfaceVariant = Color(0xFF6B6B6B),
    secondaryContainer = Color(0xFFDCE9FF),
    onSecondaryContainer = MotoBlue,
    outlineVariant = Color(0xFFE0E0E0),
)

/**
 * Follows the phone's Material You / wallpaper theme (Android 12+), so the app matches
 * the user's home-screen customisation. Dark mode uses true black for OLED.
 */
@Composable
fun MotoTheme(forceDark: Boolean = false, content: @Composable () -> Unit) {
    val dark = forceDark || isSystemInDarkTheme()
    val ctx = LocalContext.current
    val colors = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx).copy(background = Color.Black, surface = Color.Black)
            else dynamicLightColorScheme(ctx)
        dark -> fallbackDark()
        else -> fallbackLight()
    }
    MaterialTheme(colorScheme = colors, typography = Typography(), content = content)
}
