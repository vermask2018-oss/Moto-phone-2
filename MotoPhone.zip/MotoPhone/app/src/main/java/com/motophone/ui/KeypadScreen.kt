package com.motophone.ui

import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.provider.ContactsContract
import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.motophone.data.ContactItem
import com.motophone.data.ContactsRepo
import com.motophone.data.Prefs
import com.motophone.telecom.CallPlacer

private fun toneFor(k: Char): Int = when (k) {
    '0' -> ToneGenerator.TONE_DTMF_0
    '1' -> ToneGenerator.TONE_DTMF_1
    '2' -> ToneGenerator.TONE_DTMF_2
    '3' -> ToneGenerator.TONE_DTMF_3
    '4' -> ToneGenerator.TONE_DTMF_4
    '5' -> ToneGenerator.TONE_DTMF_5
    '6' -> ToneGenerator.TONE_DTMF_6
    '7' -> ToneGenerator.TONE_DTMF_7
    '8' -> ToneGenerator.TONE_DTMF_8
    '9' -> ToneGenerator.TONE_DTMF_9
    '*' -> ToneGenerator.TONE_DTMF_S
    else -> ToneGenerator.TONE_DTMF_P
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun KeypadScreen(
    number: String,
    onNumber: (String) -> Unit,
    contacts: List<ContactItem>,
    lastDialed: String?,
    isDefault: Boolean,
    onMakeDefault: () -> Unit,
    onCall: (String) -> Unit,
    onOpenSettings: () -> Unit,
) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val clipboard = LocalClipboardManager.current
    val tone = remember { runCatching { ToneGenerator(AudioManager.STREAM_DTMF, 80) }.getOrNull() }
    DisposableEffect(Unit) { onDispose { tone?.release() } }

    fun feedback(k: Char) {
        if (Prefs.bool(ctx, Prefs.KEYPAD_TONES)) tone?.startTone(toneFor(k), 120)
        if (Prefs.bool(ctx, Prefs.KEYPAD_HAPTIC)) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    fun speedDial(d: Char) {
        if (number.isNotEmpty()) return
        if (d == '1') {
            runCatching { CallPlacer.callVoicemail(ctx) }
            return
        }
        val n = Prefs.speedDial(ctx, d.digitToInt())
        if (n == null) {
            Toast.makeText(ctx, "No speed dial number set for $d", Toast.LENGTH_SHORT).show()
        } else {
            onCall(n)
        }
    }

    fun pressCall() {
        if (number.isEmpty()) {
            // Samsung behaviour: first press recalls the last dialled number
            if (!lastDialed.isNullOrEmpty()) onNumber(lastDialed)
        } else {
            onCall(number)
        }
    }

    val suggestions = remember(number, contacts) { ContactsRepo.search(contacts, number).take(3) }

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 12.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Moto Phone",
                fontSize = 24.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onOpenSettings) { Icon(Icons.Filled.Settings, "Settings") }
        }

        if (!isDefault) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Make Moto Phone your default phone app for the call screen, blocking and quick decline messages.",
                    fontSize = 13.sp,
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.size(12.dp))
                Button(onClick = onMakeDefault) { Text("Set") }
            }
        }

        // Smart-dial suggestions + typed number
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            suggestions.forEach { c ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 2.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onNumber(c.numbers.first().filter { it.isDigit() || it == '+' }) }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ContactAvatar(c.name, c.photoUri, 36.dp)
                    Spacer(Modifier.size(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.name, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            formatNumber(c.numbers.first()),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { onCall(c.numbers.first()) }) {
                        Icon(Icons.Filled.Call, "Call", tint = CallGreen)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                text = if (number.isEmpty()) "" else formatNumber(number),
                fontSize = when {
                    number.length > 14 -> 26.sp
                    number.length > 10 -> 32.sp
                    else -> 40.sp
                },
                maxLines = 1,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .combinedClickable(
                        onClick = {},
                        onLongClick = {
                            val pasted = clipboard.getText()?.text.orEmpty().filter { it.isDigit() || it in "+*#" }
                            if (pasted.isNotEmpty()) onNumber(pasted)
                        }
                    )
            )
            Spacer(Modifier.height(12.dp))
        }

        // Keys
        keyRows.forEach { row ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(76.dp)
                    .padding(horizontal = 28.dp)
            ) {
                row.forEach { (ch, sub) ->
                    val longAction: (() -> Unit)? = when {
                        ch == '0' -> ({ onNumber(number + "+") })
                        ch in '1'..'9' -> ({ speedDial(ch) })
                        else -> null
                    }
                    PadKey(
                        main = ch.toString(),
                        sub = sub,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(4.dp),
                        onDown = { feedback(ch) },
                        onTap = { onNumber(number + ch) },
                        onLong = longAction,
                    )
                }
            }
        }

        // Call row
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                if (number.isNotEmpty()) {
                    IconButton(onClick = {
                        val i = Intent(Intent.ACTION_INSERT_OR_EDIT).apply {
                            type = ContactsContract.Contacts.CONTENT_ITEM_TYPE
                            putExtra(ContactsContract.Intents.Insert.PHONE, number)
                        }
                        runCatching { ctx.startActivity(i) }
                    }) { Icon(Icons.Filled.PersonAdd, "Add to contacts", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(CallGreen)
                        .clickable { pressCall() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Call, "Call", tint = Color.White, modifier = Modifier.size(32.dp))
                }
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                if (number.isNotEmpty()) {
                    Box(
                        Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .combinedClickable(
                                onClick = { onNumber(number.dropLast(1)) },
                                onLongClick = { onNumber("") }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Backspace, "Delete",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
