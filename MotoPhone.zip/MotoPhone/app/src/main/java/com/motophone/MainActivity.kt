package com.motophone

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.mutableStateOf
import com.motophone.ui.MotoApp
import com.motophone.ui.MotoTheme

class MainActivity : ComponentActivity() {

    private val prefill = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handle(intent)
        setContent {
            MotoTheme {
                MotoApp(prefill = prefill.value, onPrefillConsumed = { prefill.value = null })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    /** tel: links and "Dial" intents from other apps pre-fill the keypad. */
    private fun handle(i: Intent?) {
        val data = i?.data
        if (data != null && data.scheme == "tel") {
            prefill.value = data.schemeSpecificPart
        }
    }
}
