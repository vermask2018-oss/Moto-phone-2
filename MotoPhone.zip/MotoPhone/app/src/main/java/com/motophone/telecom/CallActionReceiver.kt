package com.motophone.telecom

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_DECLINE -> CallManager.rejectRinging()
            ACTION_HANGUP -> CallManager.hangupAll()
        }
    }

    companion object {
        const val ACTION_DECLINE = "com.motophone.ACTION_DECLINE"
        const val ACTION_HANGUP = "com.motophone.ACTION_HANGUP"
    }
}
