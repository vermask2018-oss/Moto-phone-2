@file:Suppress("DEPRECATION")

package com.motophone.telecom

import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import com.motophone.ui.InCallActivity

class MotoInCallService : InCallService() {

    override fun onCreate() {
        super.onCreate()
        CallManager.service = this
        CallManager.onChanged = { CallNotifications.update(applicationContext, it) }
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.service = this
        CallManager.add(applicationContext, call)
        if (call.state != Call.STATE_RINGING) {
            // Outgoing call: open the call screen right away.
            startActivity(InCallActivity.intent(this))
        }
        // Incoming: CallNotifications posts a full-screen-intent notification
        // (call screen over lock screen, heads-up banner when unlocked).
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        CallManager.remove(call)
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        super.onCallAudioStateChanged(audioState)
        CallManager.setAudio(audioState)
    }

    override fun onDestroy() {
        if (CallManager.service === this) CallManager.service = null
        CallManager.onChanged = null
        CallNotifications.cancel(applicationContext)
        super.onDestroy()
    }
}
