package com.motophone.ui

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.motophone.data.BlockedRepo
import com.motophone.data.Prefs

private enum class Page { MAIN, BLOCKED, SPEED, MESSAGES }

private fun launch(ctx: Context, intent: Intent) {
    runCatching { ctx.startActivity(intent) }
        .onFailure { Toast.makeText(ctx, "Not available on this device", Toast.LENGTH_SHORT).show() }
}

@Composable
fun SettingsScreen(isDefault: Boolean, onMakeDefault: () -> Unit, onBack: () -> Unit) {
    var page by remember { mutableStateOf(Page.MAIN) }
    BackHandler { if (page == Page.MAIN) onBack() else page = Page.MAIN }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (page == Page.MAIN) onBack() else page = Page.MAIN }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
            }
            Text(
                when (page) {
                    Page.MAIN -> "Settings"
                    Page.BLOCKED -> "Blocked numbers"
                    Page.SPEED -> "Speed dial numbers"
                    Page.MESSAGES -> "Quick decline messages"
                },
                fontSize = 24.sp, fontWeight = FontWeight.SemiBold
            )
        }
        when (page) {
            Page.MAIN -> MainSettings(isDefault, onMakeDefault) { page = it }
            Page.BLOCKED -> BlockedPage()
            Page.SPEED -> SpeedDialPage()
            Page.MESSAGES -> MessagesPage()
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 24.dp, top = 20.dp, bottom = 6.dp)
    )
}

@Composable
private fun SettingRow(title: String, subtitle: String? = null, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 12.dp)
    ) {
        Text(title, fontSize = 17.sp)
        if (subtitle != null) Text(subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, key: String, default: Boolean = true) {
    val ctx = LocalContext.current
    var checked by remember { mutableStateOf(Prefs.bool(ctx, key, default)) }
    Row(
        Modifier.fillMaxWidth().clickable { checked = !checked; Prefs.setBool(ctx, key, checked) }
            .padding(horizontal = 24.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 17.sp)
            if (subtitle != null) Text(subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = { checked = it; Prefs.setBool(ctx, key, it) })
    }
}

@Composable
private fun MainSettings(isDefault: Boolean, onMakeDefault: () -> Unit, go: (Page) -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Default phone app", fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Text(
                    if (isDefault) "Moto Phone is your default phone app"
                    else "Required for incoming call screen, blocking and decline messages",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (!isDefault) Button(onClick = onMakeDefault) { Text("Set") }
        }

        SectionLabel("Calls")
        SettingRow("Blocked numbers", "Reject calls from specific numbers") { go(Page.BLOCKED) }
        SettingRow("Speed dial numbers", "Hold a digit on the keypad to call") { go(Page.SPEED) }
        SettingRow("Quick decline messages", "Messages you can send when rejecting a call") { go(Page.MESSAGES) }
        SwitchRow("Always ask which SIM", "Choose SIM 1 or SIM 2 each time you call", Prefs.ASK_SIM)
        SettingRow("Calling accounts", "Default SIM for calls, Wi-Fi calling") {
            launch(ctx, Intent(TelecomManager.ACTION_CHANGE_PHONE_ACCOUNTS))
        }
        SettingRow("Voicemail", "Voicemail number and settings") {
            launch(ctx, Intent(TelephonyManager.ACTION_CONFIGURE_VOICEMAIL))
        }

        SectionLabel("Sound & feel")
        SettingRow("Ringtone and vibration", "Open system sound settings") {
            launch(ctx, Intent(Settings.ACTION_SOUND_SETTINGS))
        }
        SwitchRow("Keypad tones", null, Prefs.KEYPAD_TONES)
        SwitchRow("Keypad vibration", null, Prefs.KEYPAD_HAPTIC)
        SwitchRow("Turn off screen near ear", "Uses the proximity sensor during calls", Prefs.PROXIMITY)

        SectionLabel("About")
        SettingRow("Moto Phone", "Version 1.0 · built for moto g96 5G") {}
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun BlockedPage() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val canBlock = remember { BlockedRepo.canBlock(ctx) }
    val list = remember(tick) { if (canBlock) BlockedRepo.list(ctx) else emptyList() }
    var number by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        if (!canBlock) {
            Text(
                "Set Moto Phone as your default phone app to manage blocked numbers.",
                modifier = Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            return@Column
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = number, onValueChange = { number = it.filter { c -> c.isDigit() || c == '+' } },
                placeholder = { Text("Phone number") }, singleLine = true,
                shape = RoundedCornerShape(28.dp), modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (number.isNotBlank() && BlockedRepo.block(ctx, number)) { number = ""; tick++ }
            }) { Text("Block") }
        }
        Spacer(Modifier.height(8.dp))
        if (list.isEmpty()) {
            Text("No blocked numbers", modifier = Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        list.forEach { (id, n) ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(formatNumber(n), fontSize = 17.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { BlockedRepo.unblock(ctx, id); tick++ }) { Icon(Icons.Filled.Delete, "Unblock") }
            }
        }
    }
}

@Composable
private fun SpeedDialPage() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Int?>(null) }
    var text by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        (1..9).forEach { d ->
            val n = remember(tick) { Prefs.speedDial(ctx, d) }
            SettingRow(
                title = "$d  ·  " + if (d == 1) "Voicemail" else (n?.let { formatNumber(it) } ?: "Not assigned"),
                subtitle = if (d == 1) "Fixed" else null
            ) {
                if (d != 1) { editing = d; text = n ?: "" }
            }
        }
    }
    editing?.let { d ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Speed dial $d") },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it.filter { c -> c.isDigit() || c == '+' } },
                    placeholder = { Text("Phone number") }, singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = { Prefs.setSpeedDial(ctx, d, text); editing = null; tick++ }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { Prefs.setSpeedDial(ctx, d, null); editing = null; tick++ }) { Text("Remove") }
            }
        )
    }
}

@Composable
private fun MessagesPage() {
    val ctx = LocalContext.current
    val msgs = remember { mutableStateListOf<String>().apply { addAll(Prefs.declineMessages(ctx)) } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        msgs.forEachIndexed { i, m ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = m,
                    onValueChange = { msgs[i] = it; Prefs.setDeclineMessages(ctx, msgs.toList()) },
                    modifier = Modifier.weight(1f).padding(vertical = 4.dp),
                    shape = RoundedCornerShape(16.dp)
                )
                IconButton(onClick = { msgs.removeAt(i); Prefs.setDeclineMessages(ctx, msgs.toList()) }) {
                    Icon(Icons.Filled.Close, "Remove")
                }
            }
        }
        if (msgs.size < 6) {
            TextButton(onClick = { msgs.add("") }) { Text("+ Add message") }
        }
        TextButton(onClick = {
            msgs.clear(); msgs.addAll(Prefs.defaultDeclineMessages)
            Prefs.setDeclineMessages(ctx, msgs.toList())
        }) { Text("Reset to defaults") }
    }
}
