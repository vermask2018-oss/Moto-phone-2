package com.motophone.data

import android.content.ContentValues
import android.content.Context
import android.provider.BlockedNumberContract
import android.provider.BlockedNumberContract.BlockedNumbers

/** Blocked numbers only work when Moto Phone is the default phone app. */
object BlockedRepo {

    fun canBlock(ctx: Context): Boolean =
        runCatching { BlockedNumberContract.canCurrentUserBlockNumbers(ctx) }.getOrDefault(false)

    fun list(ctx: Context): List<Pair<Long, String>> {
        val out = ArrayList<Pair<Long, String>>()
        runCatching {
            ctx.contentResolver.query(
                BlockedNumbers.CONTENT_URI,
                arrayOf(BlockedNumbers.COLUMN_ID, BlockedNumbers.COLUMN_ORIGINAL_NUMBER),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) out.add(c.getLong(0) to (c.getString(1) ?: ""))
            }
        }
        return out
    }

    fun block(ctx: Context, number: String): Boolean = runCatching {
        val v = ContentValues().apply { put(BlockedNumbers.COLUMN_ORIGINAL_NUMBER, number) }
        ctx.contentResolver.insert(BlockedNumbers.CONTENT_URI, v) != null
    }.getOrDefault(false)

    fun unblock(ctx: Context, id: Long) {
        runCatching {
            ctx.contentResolver.delete(
                BlockedNumbers.CONTENT_URI,
                "${BlockedNumbers.COLUMN_ID}=?",
                arrayOf(id.toString())
            )
        }
    }
}
