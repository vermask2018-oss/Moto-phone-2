package com.motophone.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CallLog.Calls

object CallLogRepo {

    fun load(ctx: Context, limit: Int = 600): List<CallLogEntry> {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            return emptyList()
        }
        val raw = ArrayList<CallLogEntry>()
        val projection = arrayOf(
            Calls._ID, Calls.NUMBER, Calls.CACHED_NAME, Calls.TYPE, Calls.DATE,
            Calls.DURATION, Calls.CACHED_PHOTO_URI, Calls.GEOCODED_LOCATION
        )
        runCatching {
            ctx.contentResolver.query(Calls.CONTENT_URI, projection, null, null, "${Calls.DATE} DESC")
                ?.use { c ->
                    while (c.moveToNext() && raw.size < limit) {
                        raw.add(
                            CallLogEntry(
                                ids = listOf(c.getLong(0)),
                                number = c.getString(1) ?: "",
                                name = c.getString(2)?.takeIf { it.isNotBlank() },
                                type = c.getInt(3),
                                date = c.getLong(4),
                                duration = c.getLong(5),
                                count = 1,
                                photoUri = c.getString(6),
                                geo = c.getString(7)?.takeIf { it.isNotBlank() },
                            )
                        )
                    }
                }
        }
        // Samsung style: consecutive calls with the same number and type are grouped "Name (3)"
        val grouped = ArrayList<CallLogEntry>()
        for (e in raw) {
            val last = grouped.lastOrNull()
            if (last != null && last.number == e.number && last.type == e.type && e.number.isNotEmpty()) {
                grouped[grouped.size - 1] = last.copy(ids = last.ids + e.ids, count = last.count + 1)
            } else {
                grouped.add(e)
            }
        }
        return grouped
    }

    fun delete(ctx: Context, ids: List<Long>) {
        if (ids.isEmpty()) return
        runCatching {
            ctx.contentResolver.delete(
                Calls.CONTENT_URI,
                "${Calls._ID} IN (${ids.joinToString(",")})",
                null
            )
        }
    }
}
