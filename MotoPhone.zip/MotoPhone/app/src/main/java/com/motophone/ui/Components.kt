package com.motophone.ui

import android.graphics.BitmapFactory
import android.net.Uri
import android.telephony.PhoneNumberUtils
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

fun formatNumber(n: String): String {
    if (n.isBlank()) return ""
    if (n.any { it == '*' || it == '#' }) return n
    return runCatching { PhoneNumberUtils.formatNumber(n, Locale.getDefault().country) }.getOrNull() ?: n
}

fun formatDuration(totalSeconds: Long): String {
    val s = if (totalSeconds < 0) 0 else totalSeconds
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

private val avatarPalette = listOf(
    Color(0xFF5C6BC0), Color(0xFF26A69A), Color(0xFFEF6C00), Color(0xFF8E24AA),
    Color(0xFF3949AB), Color(0xFF00897B), Color(0xFFD81B60), Color(0xFF6D4C41),
)

fun avatarColor(seed: String): Color =
    avatarPalette[(seed.hashCode() and Int.MAX_VALUE) % avatarPalette.size]

@Composable
fun ContactAvatar(name: String?, photoUri: String?, size: Dp = 44.dp, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(null, photoUri) {
        value = if (photoUri == null) null else withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(Uri.parse(photoUri))?.use {
                    BitmapFactory.decodeStream(it)?.asImageBitmap()
                }
            }.getOrNull()
        }
    }
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(avatarColor(name ?: "")),
        contentAlignment = Alignment.Center
    ) {
        val b = bitmap
        if (b != null) {
            Image(b, contentDescription = null, modifier = Modifier.size(size), contentScale = ContentScale.Crop)
        } else if (!name.isNullOrBlank() && name.first().isLetter()) {
            Text(
                name.first().uppercase(),
                color = Color.White,
                fontSize = (size.value * 0.42f).sp,
                fontWeight = FontWeight.Medium
            )
        } else {
            Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(size * 0.55f))
        }
    }
}

val keyRows: List<List<Pair<Char, String>>> = listOf(
    listOf('1' to "oo", '2' to "ABC", '3' to "DEF"),
    listOf('4' to "GHI", '5' to "JKL", '6' to "MNO"),
    listOf('7' to "PQRS", '8' to "TUV", '9' to "WXYZ"),
    listOf('*' to "", '0' to "+", '#' to ""),
)

/** A single dial-pad key. onDown fires on touch (tone / DTMF start), onUp on release. */
@Composable
fun PadKey(
    main: String,
    sub: String?,
    modifier: Modifier = Modifier,
    onDown: () -> Unit = {},
    onUp: () -> Unit = {},
    onTap: () -> Unit = {},
    onLong: (() -> Unit)? = null,
) {
    var pressed by remember { mutableStateOf(false) }
    val tapState by rememberUpdatedState(onTap)
    val downState by rememberUpdatedState(onDown)
    val upState by rememberUpdatedState(onUp)
    val longState by rememberUpdatedState(onLong)
    val hasLong = onLong != null
    val highlight = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)

    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(if (pressed) highlight else Color.Transparent)
            .pointerInput(hasLong) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        downState()
                        tryAwaitRelease()
                        pressed = false
                        upState()
                    },
                    onLongPress = if (hasLong) ({ _: Offset -> longState?.invoke(); Unit }) else null,
                    onTap = { tapState() },
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(main, fontSize = 30.sp, color = MaterialTheme.colorScheme.onSurface)
            if (!sub.isNullOrEmpty()) {
                Text(
                    sub,
                    fontSize = 10.sp,
                    letterSpacing = 2.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
